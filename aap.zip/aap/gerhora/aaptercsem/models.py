import datetime
from django.db import models
from django.utils import timezone
from unittest.util import _MAX_LENGTH

class Professor(models.Model):
    id_professor = models.AutoField(primary_key=True)
    nome_professor = models.CharField(max_length=45)
    matricula_professor = models.CharField(max_length=45)
    curr_materia = ''
    def __str__(self):
        return 'Professor: ' + self.nome_professor + '/ Matricula: ' + self.matricula_professor

class Perfil(models.Model):
    id_perfil = models.AutoField(primary_key=True)
    nome_perfil = models.CharField(max_length=45)
    def __str__(self):
        return 'Perfil: ' + self.nome_perfil

class Usuario(models.Model):
    id_usuario = models.AutoField(primary_key=True)
    id_professor = models.CharField(max_length=1)
    id_perfil = models.ForeignKey(Perfil, on_delete=models.CASCADE)
    nome_usuario = models.CharField(max_length=45)
    def __str__(self):
        return 'Usuario: ' + self.nome_usuario
    
class Permissao(models.Model):
    chave_permissao = models.CharField(max_length=15, primary_key=True)
    grupo_permissao = models.CharField(max_length=255)
    nome_permissao = models.CharField(max_length=255)
    def __str__(self):
        return 'Permissao: ' + self.nome_permissao
    
class PermissaoPefil(models.Model):
    chave_permissao = models.ForeignKey(Permissao, on_delete=models.CASCADE)
    tipo_permissao = models.CharField(max_length=3)
    id_perfil = models.ForeignKey(Perfil, on_delete=models.CASCADE)
    
class Curso(models.Model):
    id_curso = models.AutoField(primary_key=True)
    nome_curso = models.CharField(max_length=45)
    coordenador_curso = models.CharField(max_length=45)
    def __str__(self):
        return 'Curso: ' + self.nome_curso
    
class Materia(models.Model):
    id_materia = models.AutoField(primary_key=True)
    id_curso = models.ManyToManyField(Curso)
    id_professor = models.ManyToManyField(Professor)
    semestre_materia = models.CharField(max_length=5, default='0')
    nome_materia = models.CharField(max_length=45)
    sigla_materia = models.CharField(max_length=45)
    def __str__(self):
        return 'Materia: ' + self.nome_materia + '/ Sigla: ' + self.sigla_materia + '/ Semestre: ' + self.semestre_materia + 'º'
    
class Disponibilidade(models.Model):
    id_disponibilidade = models.AutoField(primary_key=True)
    id_professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    dia_sem_disponibilidade = models.CharField(max_length=1)
    hora_ini_disponibilidade = models.TimeField()
    hora_fin_disponibilidade = models.TimeField()
