from django.forms import ModelForm
from aaptercsem.models import *

class PerfilForm(ModelForm):
    class Meta:
        model = Perfil
        fields = ['id_perfil', 'nome_perfil']
        labels = {
            'id_perfil':'Cód.',
            'nome_perfil':'Nome'
        }