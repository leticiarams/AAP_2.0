from django.apps import AppConfig


class AaptercsemConfig(AppConfig):
    name = 'aaptercsem'
