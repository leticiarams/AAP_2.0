from django.contrib import admin

from .models import Professor
from .models import Perfil
from .models import Usuario
from .models import Permissao
from .models import PermissaoPefil
from .models import Curso
from .models import Materia
from .models import Disponibilidade


admin.site.register(Professor)
admin.site.register(Perfil)
admin.site.register(Usuario)
admin.site.register(Permissao)
admin.site.register(PermissaoPefil)
admin.site.register(Curso)
admin.site.register(Materia)
admin.site.register(Disponibilidade)
